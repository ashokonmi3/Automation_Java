package maven.test;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNGTest {
	@Test
	public void f2() {
		Assert.assertEquals("yahoo", "yahoo");

	}
}
