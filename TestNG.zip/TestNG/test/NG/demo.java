package test.NG;

import org.testng.annotations.Test;

public class demo {
  @Test
  public void f() {
  }
}
