package test.NG;

import org.testng.Assert;
import org.testng.annotations.Test;

//public class Multipletest {
//	@Test
//	public void testA() {
//		Assert.assertEquals("Gmail", "Gmail");
//	}
//
//	@Test
//	public void testC() {
//		Assert.assertEquals("Gmail", "Google");
//	}
//
//	@Test
//	public void testB() {
//		Assert.assertEquals("Yahoo", "Yahoo");
//	}
//
//}

// if x==7
//
// test pass#
// Method Checks that#

// assertEqual(a,b)a==b assertNotEqual(a,b)a!=b assertTrue(x)bool(x)is True
// assertFalse(x)bool(x)is False assertIs(a,b)a is b assertIsNot(a,b)a is not b
// assertIsNone(x)x is None assertIsNotNone(x)x is not None assertIn(a,b)a in b
// assertNotIn(a,b)a not in b
// assertIsInstance(a,b)isinstance(a,b)assertNotIsInstance(a,b)

// not isinstance(a, b)

//public class Multipletest {
//	@Test(priority = 3)
//	public void abcd() {
//		System.out.println("I am in priority 3");
//
//		Assert.assertEquals("Gmail", "Gmail");
//
//	}
//
//	@Test(priority = 2)
//	public void xyz() {
//		System.out.println("I am in priority 2");
//
//		Assert.assertEquals("Gmail", "Google");
//	}
//
//	@Test(priority = 0)
//	public void pqr() {
//		System.out.println("I am in priority 0");
//
//		Assert.assertEquals("Yahoo", "Yahoo");
//	}
//
//	@Test(priority = 1)
//	public void pqr1() {
//		System.out.println("I am in priority 1");
//
//		Assert.assertEquals("Yahoo", "Yahoo");
//	}
//
//}
// ===================================

//public class Multipletest {
//	@Test(priority = 3)
//	public void abcd() {
//		System.out.println("I am in priority 3");
//
//		Assert.assertEquals("Gmail", "Gmail");
//
//	}
//
//	@Test(priority = 2)
//	public void xyz() {
//		System.out.println("I am in priority 2");
//
//		Assert.assertEquals("Gmail", "Google");
//	}
//
//	@Test(priority = 0)
//	public void pqr() {
//		System.out.println("I am in priority 0");
//
//		Assert.assertEquals("Yahoo", "Yahoo");
//	}
//
//	@Test(priority = 0)
//	public void abcde() {
//		System.out.println("I am in priority 0 duplicate");
//
//		Assert.assertEquals("Yahoo", "Yahoo");
//	}
//
//	@Test(priority = 1)
//	public void pqr1() {
//		System.out.println("I am in priority 1");
//
//		Assert.assertEquals("Yahoo", "Yahoo");
//	}
//
//}

// ===========================================

//public class Multipletest {
//	@Test(priority = 3)
//	public void abcd() {
//		System.out.println("I am in priority 3");
//
//		Assert.assertEquals("Gmail", "Gmail");
//
//	}
//
//	@Test(priority = 2)
//	public void xyz() {
//		System.out.println("I am in priority 2");
//
//		Assert.assertEquals("Gmail", "Google");
//	}
//
//	@Test(priority = 0)
//	public void pqr() {
//		System.out.println("I am in priority 0");
//
//		Assert.assertEquals("Yahoo", "Yahoo");
//	}
//
//	@Test
//	public void abcde() {
//		System.out.println("I am without priority");
//
//		Assert.assertEquals("Yahoo", "Yahoo");
//	}
//
//	@Test(priority = 1)
//	public void pqr1() {
//		System.out.println("I am in priority 1");
//
//		Assert.assertEquals("Yahoo", "Yahoo");
//	}
//
//}

// =========================
public class Multipletest {
	@Test(priority = 3)
	public void abcd() {
		Assert.assertEquals("Gmail", "Gmail");
	}

	// assertEquals
	@Test(priority = 1, enabled = false)
	public void xyz() {
		Assert.assertEquals("Google", "Google");
	}

	@Test(priority = 2)
	public void pqr() {
		Assert.assertEquals("Yahoo", "Yahoo");
	}
}
