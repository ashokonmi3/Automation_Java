package test.test.NG;

import org.testng.annotations.Test;

public class NewTest {
	@Test(priority = 1)
	public void addVendor() {
		System.out.println("Add Vendor Successful");
	}
}
