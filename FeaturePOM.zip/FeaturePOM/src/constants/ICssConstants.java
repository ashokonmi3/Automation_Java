package constants;

public interface ICssConstants {
	public static String FONT_SIZE = "font-size";
	public static String COLOR = "color";
	public static String FONT_WEIGHT = "font-weight";
	public static String PADDING_TOP = "padding-top";
}